package com.dao;

import static com.dao.DBUtil.getSession;

import java.util.List;

import org.hibernate.Transaction;

import com.model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	public EmployeeDAOImpl() {
		new DBUtil();
	}

	@Override
	public int add(Employee employee) {
		int res = -1;
		try {
			Transaction transaction = getSession().beginTransaction();
			getSession().save(employee);
			transaction.commit();
			res = 1;
		} catch (Exception e) {
			res = 0;
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public int update(Employee employee) {
		int res = -1;
		try {
			Transaction transaction = getSession().beginTransaction();
			getSession().update(employee);
			transaction.commit();
			res = 1;
		} catch (Exception e) {
			res = 0;
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public int delete(int id) {
		int res = -1;
		try {
			Transaction transaction = getSession().beginTransaction();
			getSession().delete(new Employee(id, "", 0));
			transaction.commit();
			res = 1;
		} catch (Exception e) {
			res = 0;
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public List<Employee> view() {
		return getSession().createQuery("from Employee").list();
	}

	@Override
	public Employee view(int id) {
		return getSession().get(Employee.class, id);  
	}

}